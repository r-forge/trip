`oc.theme` <-
function(x=50) list(regions  = list(col = oc.colors(x)))

